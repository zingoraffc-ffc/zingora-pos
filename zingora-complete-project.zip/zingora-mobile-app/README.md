# Zingora Fast Food & Cafe — Mobile POS Project

An offline-first mobile POS starter with an Android/Capacitor wrapper and a separate Node.js API foundation.

## Quick start (web POS)
- Open `index.html` in a browser, or use `start-zingora.bat` on Windows.
- The browser POS stores data locally on that device. Use Settings → Backup JSON regularly.

## Build APK using GitHub on a phone
See [`MOBILE-BUILD.md`](MOBILE-BUILD.md). Upload this folder to a GitHub repository, commit `.github/workflows/build-android-apk.yml`, then run **Actions → Build Zingora Android APK → Run workflow**. Download the `Zingora-POS-APK` artifact and install the debug APK on Android. GitHub Actions builds the APK in the cloud; this repository does not contain a prebuilt APK.

## API backend
See [`server/README.md`](server/README.md) for Node.js setup, first owner account, seed data, authentication, endpoint list and payload examples.

## Important limits
This is a working project foundation/MVP, not a claim of production readiness. The HTML POS and API are currently separate data stores; the UI is not yet fully integrated with the API. PostgreSQL/LAN synchronization, printer hardware, complete refund/accounting reversals, security review, and full acceptance testing remain required before live commercial use. See [`docs/PROJECT-STATUS.md`](docs/PROJECT-STATUS.md).

## Restaurant rules represented in the backend
- A recipe is only consumed when approved; estimated recipes are not actual COGS.
- Deal products are composite menu products; deal component quantities are consumed through their component products rather than a stock item named “Deal #1”.
- Order stock deduction and order/payment creation run in a database transaction; failed stock validation rolls back the transaction.
- Stock movements and key actions are auditable.
