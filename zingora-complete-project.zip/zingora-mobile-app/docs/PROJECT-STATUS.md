# Project scope and honest status

## Included in this repository
- Mobile-responsive offline HTML POS and PWA shell.
- Capacitor Android configuration and GitHub Actions debug-APK artifact workflow.
- Separate Node.js/Express API with SQLite schema, authentication tokens, role-gated endpoints, audit log, stock ledger, purchases, expenses, shifts, reports, recipe approval, order/payment transactions, and sync-event idempotency.
- Seed data for a small set of Zingora menu items, composite deal components, and inventory master records.
- Setup and API documentation.

## Before production use
This repository is a substantial starter/MVP, not a certified production restaurant system. The HTML POS currently persists its own local data and is not fully wired to the API. There is no PostgreSQL migration yet, no full conflict-resolution/offline sync engine, no complete supplier payment ledger, no refund reversal ledger, no thermal printer/barcode device integration, no complete user administration UI, no automated end-to-end acceptance suite, and no security review. A debug APK is not a signed Play Store release.

## Required rollout checklist
- [ ] Replace sample prices and seed data with owner-approved menu and stock data.
- [ ] Set `JWT_SECRET` securely and restrict API to the trusted LAN.
- [ ] Create and test a backup/restore schedule on a separate device.
- [ ] Kitchen verifies and owner approves recipe versions before enabling inventory consumption.
- [ ] Test split tenders, cancellation/refund accounting, midnight reporting, shift reconciliation, and duplicate order submissions.
- [ ] Wire the mobile UI to API authentication and endpoints and implement offline mutation queue + reconciliation before multi-device operation.
- [ ] Migrate to PostgreSQL for multi-terminal production concurrency; run load/security tests.
- [ ] Test APK on the actual Android phone and receipt printer before operational use.
