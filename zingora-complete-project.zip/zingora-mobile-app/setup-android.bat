@echo off
setlocal
cd /d %~dp0

echo ================================================
echo ZINGORA POS - ANDROID SETUP
 echo ================================================
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed.
  echo Install Node.js 22+ and run this file again.
  pause
  exit /b 1
)
node --version
npm --version

echo.
echo Installing Capacitor packages...
npm install
if errorlevel 1 goto :error

echo.
echo Preparing web assets...
npm run prepare:web
if errorlevel 1 goto :error

if not exist android (
  echo.
  echo Creating Android project...
  npx cap add android
  if errorlevel 1 goto :error
) else (
  echo Android project already exists - skipping creation.
)

echo.
echo Syncing Android project...
npx cap sync android
if errorlevel 1 goto :error

echo.
echo SUCCESS. Android project is ready.
echo Open Android Studio with: npx cap open android
pause
exit /b 0
:error
echo.
echo SETUP FAILED. Read the error above.
pause
exit /b 1
