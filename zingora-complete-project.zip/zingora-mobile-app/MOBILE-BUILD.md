# Zingora POS — Build APK using only an Android phone

This project includes a GitHub Actions workflow that builds the Android APK in GitHub's cloud runner. You do **not** need Android Studio on your phone.

## What you need

- Android phone
- GitHub account
- The project files uploaded to a GitHub repository
- Internet connection during the cloud build

## Phone-only method

### 1. Install Termux
Use a current Termux distribution such as F-Droid/GitHub release. Open Termux.

### 2. Install tools

```bash
pkg update
pkg install git nodejs unzip
```

### 3. Extract this project

Put `zingora-mobile-apk-ready-cloud.zip` in your phone's Downloads folder, then:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip zingora-mobile-apk-ready-cloud.zip -d ZingoraPOS
cd ZingoraPOS/zingora-mobile-app
```

If your extracted folder name is different, use that folder instead.

### 4. Create a GitHub repository

In your phone browser, create a new empty repository, for example:

`zingora-pos`

Do not add a README, .gitignore, or license when creating it.

### 5. Upload from Termux

Inside the project folder:

```bash
git init
git branch -M main
git add .
git commit -m "Zingora POS Android app"
git remote add origin https://github.com/YOUR-USERNAME/zingora-pos.git
git push -u origin main
```

GitHub may ask you to authenticate. A GitHub Personal Access Token can be used instead of your account password.

### 6. Start the cloud APK build

Open the repository in your phone browser:

**Actions → Build Zingora Android APK → Run workflow**

The workflow can also start automatically when you push to `main`.

### 7. Download the APK

Wait for the workflow to finish successfully.

Open the completed workflow run → **Artifacts** → **Zingora-POS-APK** → download the ZIP.

Extract it and you will have:

`Zingora-POS-debug.apk`

Tap the APK to install it. Android may ask you to allow installation from that browser/file manager.

## Important

This produces a **debug APK** for testing and direct installation. For a Play Store release, create a properly signed release APK/AAB and protect the signing key.

The current Zingora app is an offline POS foundation. It is not yet the complete production LAN/PostgreSQL system described in the original specification.
