import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'pk.zingora.pos',
  appName: 'Zingora POS',
  webDir: 'www',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#111827'
  }
};

export default config;
