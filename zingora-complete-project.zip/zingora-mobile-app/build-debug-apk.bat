@echo off
setlocal
cd /d %~dp0
if not exist android (
  echo Android project missing. Run setup-android.bat first.
  pause
  exit /b 1
)
call npm run cap:sync
if errorlevel 1 goto :error
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto :error
cd ..
echo.
echo DEBUG APK CREATED:
echo android\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:error
echo BUILD FAILED.
pause
exit /b 1
