# Zingora POS API (local/LAN backend)

Node.js + Express + SQLite API for the Zingora POS. SQLite is appropriate for a single terminal or a small local service; for multiple concurrent terminals in a production restaurant, deploy the API on a stable LAN host and migrate the database to PostgreSQL before going live.

## Requirements
- Node.js 22+
- A supported OS/build toolchain for `better-sqlite3` if a prebuilt binary is unavailable

## Run
```sh
cd server
npm install
npm run seed
JWT_SECRET='replace-with-a-long-random-secret' npm start
```
On Windows PowerShell, set the secret first with `$env:JWT_SECRET='replace-with-a-long-random-secret'`.
Open `http://localhost:8787/api/health` to check the API.

## First-time setup
1. `POST /api/auth/bootstrap` once with JSON `{"username":"owner","password":"a-long-unique-password"}`. This endpoint locks after the first user is created.
2. `POST /api/auth/login` with those credentials; send the returned token as `Authorization: Bearer TOKEN` on protected endpoints.
3. Seed sample menu and inventory with `npm run seed` (before using the app for live sales).
4. Create your actual menu, inventory and kitchen-approved recipes. Seed recipes are intentionally absent; estimated recipe quantities must never be treated as approved actual usage.

## Main API
- `POST /api/auth/bootstrap`, `POST /api/auth/login`, `GET /api/auth/me`
- `GET/POST /api/menu`
- `GET/POST /api/inventory`, `POST /api/inventory/:id/adjust`, `GET /api/stock/low`
- `GET/POST /api/recipes`, `POST /api/recipes/:id/approve`
- `POST/GET /api/orders`, `PATCH /api/orders/:id/status`
- `POST /api/suppliers`, `POST /api/purchases`
- `POST/GET /api/expenses`
- `POST /api/shifts/open`, `POST /api/shifts/:id/close`
- `GET /api/reports/summary?from=YYYY-MM-DD&to=YYYY-MM-DD`
- `GET /api/audit`, `POST /api/sync/events`

Order payload example:
```json
{
  "order_type":"TAKEAWAY",
  "customer_name":"Walk-in",
  "discount":0,
  "tax":0,
  "delivery_fee":0,
  "items":[{"menu_item_id":1,"quantity":1,"unit_price":420}],
  "payments":[{"method":"CASH","amount":420}]
}
```

## Safety and deployment notes
- Change `JWT_SECRET`; do not expose this API to the public internet as-is.
- Create user-management, password reset, rate limiting, LAN TLS/firewall and scheduled backup procedures before deployment.
- This API has role gates, audit events, transactions, stock movement ledger, approved-recipe-only stock consumption, idempotent sync event IDs, shift close and basic reports.
- Recipe approval is restricted to OWNER/ADMIN; the business owner and kitchen must physically verify all recipes and yields.
- Deal recipes are component products, never a raw inventory item called “Deal #1”. Sample deals contain explicit component references.
- The included HTML POS still stores its interactive session data locally; connecting every screen to these API endpoints is a separate integration task. Do not assume the browser UI and API share data automatically.
