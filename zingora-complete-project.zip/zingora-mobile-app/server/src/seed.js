const db = require('./db');
const addMenu=db.prepare('INSERT OR IGNORE INTO menu_items(sku,name,category,price,deal_components) VALUES(?,?,?,?,?)');
const addInv=db.prepare('INSERT OR IGNORE INTO inventory_items(sku,name,unit,on_hand,minimum,unit_cost) VALUES(?,?,?,?,?,?)');
const menu=[
['ZG-BUR-ZINGER','Zinger Burger','BURGERS',420,[]],['ZG-BUR-THUNDER','Thunder Spicy Burger','BURGERS',350,[]],['ZG-BUR-KABABISH','Kababish Burger','BURGERS',280,[]],['ZG-BUR-PATTY','Chicken Patty Burger','BURGERS',300,[]],['ZG-FRY-REG','Regular Fries','FRIED SIDELINES',180,[]],['ZG-DRK-REG','Regular Drink','COLD DRINKS',100,[]],['ZG-PIZ-SM','Small Pizza','PIZZA',450,[]],['ZG-WING-HOT','Hot Wings','FRIED SIDELINES',80,[]],['ZG-NUGGETS','Nuggets','FRIED SIDELINES',30,[]],['ZG-PIZ-MED','Medium Pizza','PIZZA',900,[]],['ZG-PIZ-LRG','Large Pizza','PIZZA',1300,[]],['ZG-DRK-1L','1 Liter Drink','COLD DRINKS',180,[]],['ZG-DRK-15L','1.5 Liter Drink','COLD DRINKS',250,[]]
];
const byName={};for(const [sku,name,cat,price,components] of menu){addMenu.run(sku,name,cat,price,JSON.stringify(components));byName[name]=db.prepare('SELECT id FROM menu_items WHERE sku=?').get(sku).id}
const deals=[['ZG-DEAL-01','Deal #1',580,[['Zinger Burger',1],['Regular Fries',1],['Regular Drink',1]]],['ZG-DEAL-02','Deal #2',450,[['Thunder Spicy Burger',1],['Regular Drink',1]]],['ZG-DEAL-03','Deal #3',380,[['Kababish Burger',1],['Regular Drink',1]]],['ZG-DEAL-04','Deal #4',520,[['Chicken Patty Burger',1],['Regular Fries',1],['Regular Drink',1]]],['ZG-DEAL-10','Deal #10',630,[['Small Pizza',1],['Regular Drink',1]]]];
for(const [sku,name,price,parts] of deals){const components=parts.map(([n,quantity])=>({menu_item_id:byName[n],quantity}));addMenu.run(sku,name,'REGULAR DEALS',price,JSON.stringify(components))}
const inventory=[['RAW-CHICKEN','Chicken fillet','kg',0,3,900],['RAW-FLOUR','Flour','kg',0,5,180],['RAW-OIL','Cooking oil','liter',0,5,550],['RAW-POTATO','Potatoes','kg',0,5,120],['PACK-BAG','Takeaway bag','piece',0,50,8],['PACK-BOX','Food box','piece',0,50,12],['DRINK-CAN','Drink bottle/can','piece',0,24,70],['RAW-CHEESE','Cheese','kg',0,2,1400],['RAW-BUN','Burger bun','piece',0,30,35]];
for(const x of inventory)addInv.run(...x);
console.log(`Seeded ${db.prepare('SELECT COUNT(*) n FROM menu_items').get().n} menu items and ${db.prepare('SELECT COUNT(*) n FROM inventory_items').get().n} inventory items.`);
