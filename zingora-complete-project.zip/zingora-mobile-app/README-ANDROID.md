# Zingora POS — Windows Android APK Setup

This package wraps the existing Zingora offline web POS in a native Android application using Capacitor.

## 1. Install required software

Install:

1. Node.js 22 or newer.
2. Android Studio (current stable).
3. Android SDK Platform/API 24 or newer. Capacitor's current Android setup requires Android Studio and an Android SDK; Android Studio supplies the appropriate JDK. See the official docs linked in the main README.

During Android Studio first launch, allow it to install the Android SDK and required SDK tools.

## 2. Extract the ZIP

Extract the ZIP to a simple path, for example:

`C:\ZingoraPOS`

Avoid a very long path.

## 3. Create the Android project

Double-click:

`setup-android.bat`

It will:
- install npm dependencies
- prepare the web assets
- create the Android project
- synchronize Capacitor

The first run needs internet access to download npm/Gradle dependencies.

## 4. Open in Android Studio

From Command Prompt in `C:\ZingoraPOS`:

`npx cap open android`

Android Studio will open the native project.

## 5. Test on an Android phone

On the phone:
- Enable Developer Options.
- Enable USB debugging.
- Connect USB.
- Accept the computer authorization prompt.

In Android Studio select the phone and press Run.

## 6. Build an installable debug APK

Double-click:

`build-debug-apk.bat`

The APK will be at:

`android\app\build\outputs\apk\debug\app-debug.apk`

Copy that APK to an Android phone and tap it to install. Android may ask you to allow installation from that source.

## 7. Make a signed release APK

For a real release APK, create a private signing keystore and never share it publicly.

Recommended Android Studio route:

Build > Generate Signed App Bundle / APK > APK

Create/select a keystore, choose `release`, then build.

Keep the keystore and passwords safe. Future updates must use the same signing identity.

## 8. Command-line release build

After configuring signing, Capacitor can build an APK with:

`npx cap build android --androidreleasetype APK`

For Google Play, use an AAB instead:

`npx cap build android --androidreleasetype AAB`

## 9. Change app identity

Current application ID:

`pk.zingora.pos`

App name:

`Zingora POS`

These are configured in `capacitor.config.ts`. The Android project can also be adjusted in Android Studio.

## 10. Updating the app

After changing `index.html`:

`npm run cap:sync`

Then rebuild the APK.

## 11. Offline behavior

The current mobile build stores POS data locally in browser storage inside the app. It does not yet provide the full server/PostgreSQL/LAN synchronization architecture from the original specification.

Do not treat the current local-storage build as the final multi-terminal production database.
